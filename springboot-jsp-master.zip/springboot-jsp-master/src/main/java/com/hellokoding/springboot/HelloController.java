package com.hellokoding.springboot;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hellokoding.springboot.model.Contact;
import com.hellokoding.springboot.repository.ContactRepository;

@Controller
public class HelloController {
	@Autowired
	private ContactRepository contactRepository;
    /*@RequestMapping("/hello")
    public String hello(ModelAndView model) {
		List<Contact> listContact = new ArrayList<Contact>();
		Iterable<Contact> contactList = contactRepository.findAll();
		for(Contact contact: contactList) {
			System.out.println(contact.toString());
			listContact.add(contact);
	      }
		model.addObject("listContact", listContact);
//		model.setViewName("hello");

		return "hello";

	}*/
	
	@RequestMapping(value = "/saveContact", method = RequestMethod.POST)
	public ModelAndView saveContact(@ModelAttribute Contact contact) {
		contactRepository.save(contact);
		return new ModelAndView("redirect:/");
	}

    
	@RequestMapping(value = "/newContact", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Contact newContact = new Contact();
		model.addObject("contact", newContact);
		model.setViewName("ContactForm");
		return model;
	}

	@RequestMapping(value = "/deleteContact", method = RequestMethod.GET)
	public ModelAndView deleteContact(HttpServletRequest request) {
		int contactId = Integer.parseInt(request.getParameter("id"));
		contactRepository.delete(contactId);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/editContact", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		System.out.println(request.getParameter("id"));
		int contactId = Integer.parseInt(request.getParameter("id"));
		Contact contact = contactRepository.findOne(contactId);
		ModelAndView model = new ModelAndView("ContactForm");
		model.addObject("contact", contact);
		
		return model;
	}

	
    @RequestMapping("/hello")
    public ModelAndView hello(ModelAndView model) throws IOException{
		List<Contact> listContact = new ArrayList<Contact>();
		Iterable<Contact> contactList = contactRepository.findAll();
		for(Contact contact: contactList) {
			System.out.println(contact.toString());
			listContact.add(contact);
	      }
		model.addObject("listContact", listContact);
		model.setViewName("hello");

		return model;

	}

}
