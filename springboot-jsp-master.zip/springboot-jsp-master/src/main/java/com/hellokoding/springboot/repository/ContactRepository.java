package com.hellokoding.springboot.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import com.hellokoding.springboot.model.*;
@RepositoryRestResource
public interface ContactRepository extends CrudRepository<Contact, Integer>{

}
